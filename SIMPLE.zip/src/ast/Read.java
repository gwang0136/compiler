package ast;
import java.io.*;
import environment.*;

public class Read extends Statement
{
    private String id;

    public Read(String id)
    {
        this.id = id;
    }

    public void exec(Environment env)
    {
        System.out.println("To what value would you like to set " + id + " to? ");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int val = 0;
        try
        {
            val = Integer.parseInt(reader.readLine());
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }

        Number num = new Number(val);
        Assign as = new Assign(id, num);
        as.exec(env);

    }
}
