package ast;
import java.io.*;
import environment.*;


public class Display extends Statement
{
    private Expression expression;
    private Read read;

    public Display(Expression expression, Read read)
    {
        this.expression = expression;
        this.read = read;
    }

    public void exec(Environment env)
    {
        System.out.println(expression.eval(env));
        if(read!=null)
            read.exec(env);
    }
}
